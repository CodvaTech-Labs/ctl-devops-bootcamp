+++
archetype = "home"
title = "Cap'n Hugo Relearrrn Theme"
+++
{{< piratify true >}}