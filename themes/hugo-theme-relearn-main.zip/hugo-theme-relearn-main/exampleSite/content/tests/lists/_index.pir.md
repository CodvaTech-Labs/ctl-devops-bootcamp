+++
description = "Test shortcodes inside of list items"
title = "Lists"
+++
{{< piratify >}}