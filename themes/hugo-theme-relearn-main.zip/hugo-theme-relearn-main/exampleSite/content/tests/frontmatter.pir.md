+++
description = "Test default settings for snippets of the VSCode Front Matter extension"
title = "VSCode Front Matter"
+++
{{< piratify >}}