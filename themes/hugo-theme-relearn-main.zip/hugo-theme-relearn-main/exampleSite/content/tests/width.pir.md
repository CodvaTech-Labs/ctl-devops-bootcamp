+++
description = "Test dynamic width rrresizing o' content if scrrrollbar 's present"
title = "Width"
+++
{{< piratify >}}