+++
description = "Some test'n fer different styles used 'n rules highlightn'n an' preformatted blocks"
title = "Code"
+++
{{< piratify >}}