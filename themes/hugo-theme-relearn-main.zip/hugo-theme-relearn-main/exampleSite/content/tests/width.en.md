+++
description = "Test dynamic width resizing of content if scrollbar is present"
title = "Width"
+++

{{% notice primary %}}
Make a visible block
{{% /notice %}}

{{% notice primary %}}
And another one
{{% /notice %}}
