+++
description = "Testing different markdown constructs inside of tables"
title = "Tables"
+++
{{< piratify >}}