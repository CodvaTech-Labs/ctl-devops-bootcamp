+++
description = "Test default settings for snippets of the VSCode Front Matter extension"
title = "VSCode Front Matter"
+++

## Empty Properties

{{< attachments title="" pattern="" sort="" style="" color="" icon="" />}}

{{< badge title="" style="" color="" icon="" >}}{{< /badge >}}

{{< button href="" target="" type="" style="" color="" icon="" iconposition="" >}}{{< /button >}}

{{< children description="" depth="" sort="" showhidden="" containerstyle="" style="" >}}

{{% expand title="" open="" %}}{{% /expand %}}

a{{< icon  >}}a

{{< include file="" hidefirstheading="" >}}

````math align=""

````

````mermaid align="" zoom=""

````

{{% notice title="" style="" color="" icon="" %}}{{% /notice %}}

{{< siteparam  >}}

{{< openapi src="" >}}

{{< tabs groupid="" >}}
{{% tab name="" %}}

{{% /tab %}}
{{% tab name="" %}}

{{% /tab %}}
{{< /tabs >}}
