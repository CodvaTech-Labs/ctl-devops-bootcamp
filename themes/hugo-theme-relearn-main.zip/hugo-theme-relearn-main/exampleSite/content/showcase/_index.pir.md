+++
title = "Showcase"
[_build]
  render = "always"
  list = "never"
  publishResources = true
+++
{{< piratify >}}