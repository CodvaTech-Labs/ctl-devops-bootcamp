+++
tags = ["content"]
title = "Marrrkdown rules"
weight = 3
+++
{{< piratify >}}