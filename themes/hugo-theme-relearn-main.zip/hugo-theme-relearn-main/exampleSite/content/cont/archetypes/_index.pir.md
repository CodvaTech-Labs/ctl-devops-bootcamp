+++
title = "Arrrchetypes"
weight = 2
+++
{{< piratify >}}