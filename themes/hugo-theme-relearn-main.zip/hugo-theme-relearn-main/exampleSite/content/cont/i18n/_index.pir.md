+++
title = "Multilingual an' i18n"
weight = 6
+++
{{< piratify >}}