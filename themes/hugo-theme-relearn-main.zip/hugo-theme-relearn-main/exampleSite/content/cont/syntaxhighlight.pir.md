+++
title = "Code highlight'n"
weight = 4
+++
{{< piratify >}}