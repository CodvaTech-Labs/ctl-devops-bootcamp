+++
descrption = "Get value o' ship parrrams varrriables 'n yer plank"
title = "Ship param"
+++
{{< piratify >}}