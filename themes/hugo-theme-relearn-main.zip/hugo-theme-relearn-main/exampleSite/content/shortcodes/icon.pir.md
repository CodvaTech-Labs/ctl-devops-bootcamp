+++
aliases = "/pir/cont/icons"
descrption = "Nice ay'cons fer yer plank"
title = "Icon"
+++
{{< piratify >}}