## Create this Page

You need to create a file for this page. You can either

- create a file in the `content` folder and fill it with Markdown content
  - inside a folder named by the page's title like `<TITLE>/_index.md` or `<TITLE>/index.md`
  - named by the page's title like `<TITLE>.md`
- create a file in the `static` folder and fill it with HTML content
  - inside a folder named by the page's title like `<TITLE>/index.html`
